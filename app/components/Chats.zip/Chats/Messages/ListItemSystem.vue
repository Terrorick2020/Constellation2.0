<template>
  <div class="mt-4 rounded-2xl border p-4">
    <div class="text-sm font-extrabold">Система:</div>
    <div class="mt-[5px] text-sm text-gray-500">
      Если ответ не поступит, вы сможете отправить следующее сообщение через 48 часов.
    </div>
  </div>
</template>
