<template>
  <div class="mb-4 flex flex-nowrap items-center gap-x-[10px]">
    <span class="h-[1px] w-full bg-gray-200"></span>
    <span class="text-sm text-gray-500">Сегодня</span>
    <span class="h-[1px] w-full bg-gray-200"></span>
  </div>
</template>
